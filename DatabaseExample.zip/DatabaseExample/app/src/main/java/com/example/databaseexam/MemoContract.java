package com.example.databaseexam;

import android.provider.BaseColumns;

// Memo Table 정보를 담을 계약 클래스
public final class MemoContract {

    // 상수들을 정의해서 가져다 쓰는 용도
    private MemoContract() {};

    public static class MemoEntry implements BaseColumns {

        public static final String TABLE_NAME = "memo";
        public static final String COLUMN_NAME_TITLE = "title";
        public static final String COLUMN_NAME_CONTENTS = "contents";


    }

}
