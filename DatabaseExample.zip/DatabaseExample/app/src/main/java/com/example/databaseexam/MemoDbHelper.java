package com.example.databaseexam;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;

public class MemoDbHelper extends SQLiteOpenHelper {

    private static MemoDbHelper sInstance;

    private static final int DB_VERSION = 1;
    private static final String DB_NAME = "Memo.db"; // 파일 이름
    private static final String SQL_CREATE_ENTREIS =
            String.format("CREATE TABLE %s (%s INTEGER PRIMARY KEY AUTOINCREMENT, %s TEXT, %s TEXT)",
                    MemoContract.MemoEntry.TABLE_NAME,
                    MemoContract.MemoEntry._ID,
                    MemoContract.MemoEntry.COLUMN_NAME_TITLE,
                    MemoContract.MemoEntry.COLUMN_NAME_CONTENTS);
    private static final String SQL_DELETE_ENTRIES =
            "DROP TABLE IF EXISTS " + MemoContract.MemoEntry.TABLE_NAME;

    public static MemoDbHelper getInstance(Context context) {
        if (sInstance == null) {
            sInstance = new MemoDbHelper(context);
        }
        return sInstance;
    }

    // 생성자 부분
    private MemoDbHelper(Context context) {
        super(context, DB_NAME, null, DB_VERSION);
    }

    @Override // 최초에 DB를 생성하는 경우
    public void onCreate(SQLiteDatabase db) {
        db.execSQL(SQL_CREATE_ENTREIS);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        // DB를 삭제하고
        db.execSQL(SQL_DELETE_ENTRIES);
        // 다시 생성해주는 방식으로 구현
        db.execSQL(SQL_CREATE_ENTREIS);
        // onCreate(db);
    }
}
