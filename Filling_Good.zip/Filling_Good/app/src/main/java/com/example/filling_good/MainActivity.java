package com.example.filling_good;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.app.DatePickerDialog;
import android.app.TimePickerDialog;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CalendarView;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.TimePicker;
import android.widget.Toast;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Calendar;

public class MainActivity extends AppCompatActivity {

    private CalendarView mCalendarView;
    private TextView mDisplayStartDate, mDisplayEndDate, mDisplayStartTime, mDisplayEndTime;
    private DatePickerDialog.OnDateSetListener mDateSetListener;
    private Button load_event;
    String FILE_NAME;
    Button saveButton;
    RadioGroup radioGroup;
    RadioButton fixed, hardly, easily;
    TextView textView;
    String amPm;
    String startDate, endDate, startTime, endTime, title, place, memo, priority;
    EditText editText;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        mCalendarView = findViewById(R.id.calenderView);
        textView = findViewById(R.id.event_start_date);
        mCalendarView.setOnDateChangeListener(new CalendarView.OnDateChangeListener() {
            @Override
            public void onSelectedDayChange(@NonNull CalendarView view, int year, int month, int dayOfMonth) {
                startDate = (year) + "." + (month+1) + "." + dayOfMonth;
                textView.setText(startDate);
            }
        });

        mDisplayStartTime = findViewById(R.id.event_start_time);
        mDisplayStartTime.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Calendar cal = Calendar.getInstance();
                int currentHour = cal.get(Calendar.HOUR_OF_DAY);
                int currentMinute = cal.get(Calendar.MINUTE);

                TimePickerDialog dialog = new TimePickerDialog(
                        MainActivity.this, new TimePickerDialog.OnTimeSetListener() {
                    @Override
                    public void onTimeSet(TimePicker view, int hourOfDay, int minute) {
                        if(hourOfDay >= 12) {
                            amPm = "PM";
                        } else {
                            amPm = "AM";
                        }
                        startTime = String.format("%02d:%02d ", hourOfDay, minute) + amPm;
                        mDisplayStartTime.setText(startTime);
                    }
                }, currentHour, currentMinute, false);

                dialog.show();
            }
        });

        mDisplayEndDate = findViewById(R.id.event_end_date);
        mDisplayEndDate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Calendar cal = Calendar.getInstance();
                int year = cal.get(Calendar.YEAR);
                int month = cal.get(Calendar.MONTH);
                int day = cal.get(Calendar.DAY_OF_MONTH);

                DatePickerDialog dialog = new DatePickerDialog(
                        MainActivity.this,
                        android.R.style.Theme_Holo_Light_Dialog_MinWidth,
                        mDateSetListener,
                        year, month, day);

                dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
                dialog.show();

            }
        });

        mDateSetListener = new DatePickerDialog.OnDateSetListener() {
            @Override
            public void onDateSet(DatePicker view, int year, int month, int dayOfMonth) {
                endDate = (year) + "." + (month+1) + "." + dayOfMonth;
                mDisplayEndDate.setText(endDate);
            }
        };

        mDisplayEndTime = findViewById(R.id.event_end_time);
        mDisplayEndTime.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Calendar cal = Calendar.getInstance();
                int currentHour = cal.get(Calendar.HOUR_OF_DAY);
                int currentMinute = cal.get(Calendar.MINUTE);

                TimePickerDialog dialog = new TimePickerDialog(
                        MainActivity.this, new TimePickerDialog.OnTimeSetListener() {
                    @Override
                    public void onTimeSet(TimePicker view, int hourOfDay, int minute) {
                        if(hourOfDay >= 12) {
                            amPm = "PM";
                        } else {
                            amPm = "AM";
                        }
                        endTime = String.format("%02d:%02d ", hourOfDay, minute) + amPm;
                        mDisplayEndTime.setText(endTime);
                    }
                }, currentHour, currentMinute, false);

                dialog.show();
            }
        });

        fixed = findViewById(R.id.fixed);
        hardly = findViewById(R.id.hardly);
        easily = findViewById(R.id.easily);

        saveButton = findViewById(R.id.save_event);
        saveButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                FileOutputStream fos = null;

                try {
                    FILE_NAME = "example";
//                    FILE_NAME = startDate + "_" + startTime;
                    fos = openFileOutput(FILE_NAME, MODE_PRIVATE);
                    fos.write((startDate+"\n").getBytes());
                    fos.write((startTime+"\n").getBytes());
                    fos.write((endDate+"\n").getBytes());
                    fos.write((endTime+"\n").getBytes());

                    editText = findViewById(R.id.event_title);
                    title = editText.getText().toString();
                    editText = findViewById(R.id.event_place);
                    place = editText.getText().toString();
                    editText = findViewById(R.id.event_memo);
                    memo = editText.getText().toString();

                    fos.write((title+"\n").getBytes());
                    fos.write((place+"\n").getBytes());
                    fos.write((memo+"\n").getBytes());

                    if (fixed.isChecked()) {
                        priority = fixed.getText().toString();
                    } else if (hardly.isChecked()) {
                        priority = hardly.getText().toString();
                    } else {
                        priority = easily.getText().toString();
                    }
                    fos.write((priority+"\n").getBytes());

                    Toast.makeText(MainActivity.this, "Saved to " + getFilesDir() + "/" + FILE_NAME, Toast.LENGTH_LONG).show();
                } catch (FileNotFoundException e) {
                    e.printStackTrace();
                } catch (IOException e) {
                    e.printStackTrace();
                } finally {
                    if (fos != null) {
                        try {
                            fos.close();
                        } catch (IOException e) {
                            e.printStackTrace();
                        }
                    }
                }

            }
        });

        load_event = findViewById(R.id.load_event);
        load_event.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, SubActivity.class);
                startActivity(intent);

            }
        });



//        radioGroup = findViewById(R.id.radioGroup);
//        textView = findViewById(R.id.tv_selected);
//        Button buttonApply = findViewById(R.id.apply);
//        buttonApply.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                int radioID = radioGroup.getCheckedRadioButtonId();
//                radioButton = findViewById(radioID);
//
//                textView.setText("Your choice: " + radioButton.getText());
//
//            }
//        });

    }

//    public void checkButton(View v) {
//        int radioID = radioGroup.getCheckedRadioButtonId();
//        radioButton = findViewById(radioID);
//
//        Toast.makeText(this, "이벤트의 우선순위: " + radioButton.getText(), Toast.LENGTH_SHORT).show();
//    }
}
